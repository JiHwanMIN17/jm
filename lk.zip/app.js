// const loginform=document.querySelector("#login-form");
// const loginInput=document.querySelector("#login-form input");


// function a(event){
//     event.preventDefault();
//     console.log(loginInput.value);
// }

// loginform.addEventListener("submit",a);

const loginForm=document.querySelector("#login-form");
const loginInput=document.querySelector("#login-form input");
const greeting=document.querySelector("#greeting");
// const HDN_CLASS="hidden";
// function a(event){
//     event.preventDefault();
//     loginForm.classList.add(HDN_CLASS);
//     const username=loginInput.value;
//     greeting.innerText="Hello"+username;
//     greeting.classList.remove(HDN_CLASS);   
// }

// loginForm.addEventListener("submit",a);

const HDN_CLASS="hidden";

function a(event){
    event.preventDefault();
    loginForm.classList.add(HDN_CLASS);
    const username=loginInput.value;
    localStorage.setItem("username",username)
    greeting.innerHTML=`hello ${username}`;
    greeting.classList.remove(HDN_CLASS);
}

loginForm.addEventListener("submit",a);